package com.Serveur_09_12_2019.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Serveur09122019ApplicationTests {

	@Test
	void contextLoads() {
	}

}
