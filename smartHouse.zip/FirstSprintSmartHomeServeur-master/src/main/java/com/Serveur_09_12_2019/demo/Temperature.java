package com.Serveur_09_12_2019.demo;


import javax.persistence.Entity;

import javax.persistence.Id;



import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
public class Temperature {
	
	float value;
	
	@Id
	// @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
	String time;
	
	public Temperature() {
		super();
	}
	
	public Temperature(int value) {
		super();
		this.value = value;
	}
	
	public Temperature(int value, String time) {
		super();
		this.value = value;
		this.time = time;
	}
	public float getValue() {
		return value;
	}
	public void setValue(float value) {
		this.value = value;
	}
	public String gettime() {
		return time;
	}
	public void settime(String time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "Temp [value=" + value + ", time=" + time + "]";
	}
	
}
