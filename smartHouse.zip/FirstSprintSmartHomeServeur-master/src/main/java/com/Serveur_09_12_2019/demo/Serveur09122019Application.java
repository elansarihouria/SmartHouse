package com.Serveur_09_12_2019.demo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Serveur09122019Application {
	
	public static void main(String[] args) {
		ConfigurableApplicationContext context =SpringApplication.run(Serveur09122019Application.class, args);
		/* Watcher watcher=context.getBean(Watcher.class);
		 watcher.hdi();*/
		 tempStepWatcher stepWatcher=context.getBean(tempStepWatcher.class);
		 stepWatcher.hdi();
	}
}
