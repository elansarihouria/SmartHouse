package com.Serveur_09_12_2019.demo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.List;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class MyController {
	char c='"';
	char p=':';
	@Autowired
	Repositry repo;
	
	@GetMapping("/GetTemperature")
	@ResponseBody
	public List<Temperature> getTemperature(){
		return repo.findAll();
	}
	
	@GetMapping("/LedOn")
	@ResponseBody
	public boolean LedOn(){
		Action.Led(true);
		return true;
	}
	
	@GetMapping("/LedOff")
	@ResponseBody
	public boolean LedOff(){
		
		Action.Led(false);
		return false;
	}
	
	@GetMapping("/getMin")
	@ResponseBody
	public float Min() {
		return repo.getMin();
	}
	
	
	 @GetMapping("/getInfoTemp")
	 @ResponseBody
	 public Min_Max_Med getInfo() {
		 Min_Max_Med m=new Min_Max_Med(repo.getMin(), repo.getMax(), repo.getAvg());
		 return m;
	 }
	 @GetMapping("/step")
	 @ResponseBody
	 public String getstep(@RequestParam String step) throws IOException {
		 Path path = Paths.get("/home/houria/Documents/GSEII2/smartHouse/tempoConfig/step1.json");
		 	
		String strValue ="{ " + c + "step" +c + p +" " +c+ step+c +"}";
		// Path path = Paths.get(fileName);
		 byte[] bytes = strValue.getBytes() ;
		 Files.write(path, bytes);
	     return strValue;
	 }
	 
	/* @RequestMapping(method = RequestMethod.POST, value = "/payments/confirm")
	 public void receiveCallback(HttpServletRequest request) {
	     try {
	         StringBuilder sb = new StringBuilder();
	         sb.append("Headers:\n");
	         Enumeration<String> headerNames = request.getHeaderNames();
	         while (headerNames.hasMoreElements()) {
	             String headerName = headerNames.nextElement();
	             Enumeration<String> headers = request.getHeaders(headerName);
	             while (headers.hasMoreElements()) {
	                 String headerValue = headers.nextElement();
	                 sb.append(headerName).append(':').append(headerValue).append('\n');
	             }
	         }
	         sb.append("\nParameters:\n");
	         for(Entry entry: (Set<Entry>) request.getParameterMap().entrySet(){
	             sb.append(entry.getKey()).append(':').append(entry.getValue()).append('\n');
	         }
	         byte[] data = sb.toString().getBytes();

	         File file = new File(System.getProperty("java.io.tmpdir") + "test"
	                 + System.currentTimeMillis() + ".txt");
	         FileOutputStream fos = new FileOutputStream(file);
	         fos.write(data);
	         fos.close();
	     } catch (Exception e) {
	         logger.error("Error writing request", e);
	     }
	 }*/
	
}
