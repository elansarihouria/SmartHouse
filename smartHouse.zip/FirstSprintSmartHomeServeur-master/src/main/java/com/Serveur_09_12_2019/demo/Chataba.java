package com.Serveur_09_12_2019.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Chataba {

static public Boolean Mhi(Path p) {
		
		try {
			Files.delete(p);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

}
