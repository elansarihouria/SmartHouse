package com.Serveur_09_12_2019.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Led {
	
	@Id
	int ID;
	
	boolean status;
	
	int brightness;
	
	public Led(int iD, boolean status, int brightness) {
		super();
		ID = iD;
		this.status = status;
		this.brightness = brightness;
	}
	
	public Led(int iD, boolean status) {
		super();
		ID = iD;
		this.status = status;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public int getBrightness() {
		return brightness;
	}

	public void setBrightness(int brightness) {
		this.brightness = brightness;
	}

	@Override
	public String toString() {
		return "Led [ID=" + ID + ", status=" + status + ", brightness=" + brightness + "]";
	}

}
