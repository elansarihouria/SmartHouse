package com.Serveur_09_12_2019.demo;

import java.time.LocalDateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface Repositry extends JpaRepository<Temperature, LocalDateTime> {
	
	@Query(value = "SELECT MIN(value) FROM Temperature LIMIT 5;",nativeQuery = true)
	float getMin();
	
	@Query(value = "SELECT MAX(value) FROM Temperature LIMIT 5;",nativeQuery = true)
	float getMax();
	
	@Query(value = "SELECT AVG(value) FROM Temperature LIMIT 5;",nativeQuery = true)
	float getAvg();

	
}
