package com.Serveur_09_12_2019.demo;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class Watcher {
	@Autowired
	 Repositry repo;
	public Watcher() {
		
	}
	
	public File getTheFileName(String PathOfTheFolder) {
		File folder=new File(PathOfTheFolder);
		File[] files=folder.listFiles();
		if(files[0].isFile()) {
			return files[0];
		}else {
			System.out.println("l file rah null");
			return  null;
		}
	}
	
	public Path getPath(File f) {
		return f.toPath();
	}
	
	public Temperature ReadDataDronJsonFile(File TheFile) throws JsonParseException, JsonMappingException, IOException {
				ObjectMapper objectMapper = new ObjectMapper();
				 Temperature temp =objectMapper.readValue(TheFile, Temperature.class);
				 if(temp.time==null) {
					 String pattern = "y-M-d H:m:s"; 
					 SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
					 temp.settime(simpleDateFormat.format(new Date()).toString());
					// temp
					// temp.settime(LocalDateTime.now().toString()); // hadchi bach yb9a 5dame hadchi wa5a l hard may3tewnach date
				 }else {
					 System.out.println("ra sefto date");
				 }
				 return temp;
	}
	
	public void hdi() {
		   try( WatchService watcher = FileSystems.getDefault().newWatchService()) {
	            // Creates a instance of WatchService.
	           
	            String chemin="/home/smartHouse" ;
	            	
	            // Registers the logDir below with a watch service.
	            Path logDir = Paths.get(chemin);
	            logDir.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
	            
	            // Monitor the logDir at listen for change notification.
	            while (true) {
	            	//System.out.println("lllfl");
	                WatchKey key = watcher.take();
	                
	                Thread.sleep(50);
	                
	                for (WatchEvent<?> event : key.pollEvents()) {
	                    WatchEvent.Kind<?> kind = event.kind();
	                    if ( StandardWatchEventKinds.ENTRY_CREATE.equals(kind)) {
	                     	Temperature t=this.ReadDataDronJsonFile(this.getTheFileName(chemin));
	                    	System.out.println(t);
	                    	 repo.save(t);
	                    	 Thread.sleep(500);
	                    	 Chataba.Mhi(this.getPath(this.getTheFileName(chemin)));
	                    }
	                }
	                key.reset();
	            }
	        } catch (IOException | InterruptedException e) {
	            e.printStackTrace();
	        }
	}
}
