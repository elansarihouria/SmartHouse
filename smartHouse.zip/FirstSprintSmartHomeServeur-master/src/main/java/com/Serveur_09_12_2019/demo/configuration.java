package com.Serveur_09_12_2019.demo;

import javax.persistence.Entity;
import javax.persistence.Id;


public class configuration {

	String step;

	public configuration() {
	super();
	}

	@Override
	public String toString() {
		return "configuration [step=" + step + "]";
	}

	public String getStep() {
		return step;
	}

	public void setStep(String step) {
		this.step = step;
	}
}
