package com.Serveur_09_12_2019.demo;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class tempStepWatcher {
public static String STEP ;

	@Autowired
	 Repositry repo;

	public tempStepWatcher() {
		
	}
	
	public File getTheFileName(String PathOfTheFolder) {
		File folder=new File(PathOfTheFolder);
		File[] files=folder.listFiles();
		if(files[0].isFile()) {
			return files[0];
		}else {
			System.out.println("l file rah null");
			return  null;
		}
	}
	
	public Path getPath(File f) {
		return f.toPath();
	}

	
	public  configuration ReadDataDronTextFile(File TheFile) throws JsonParseException, JsonMappingException, IOException {
				ObjectMapper objectMapper = new ObjectMapper();
				configuration step =objectMapper.readValue(TheFile,configuration.class) ;  //objectMapper.readValue(TheFile, Temperature.class);
			
				 return step;
	}
	
	
	public void hdi() {
		System.out.println("dddddddddddddddddddddddddddddddddddddddddddd");
		   try( WatchService watcher = FileSystems.getDefault().newWatchService()) {
	            // Creates a instance of WatchService.
	           
	            String chemin="/home/houria/Documents/GSEII2/smartHouse/tempoConfig" ;
	            	
	            // Registers the logDir below with a watch service.
	            Path logDir = Paths.get(chemin);
	            logDir.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
	            
	            // Monitor the logDir at listen for change notification.
	            while (true) {
	            	//System.out.println("lllfl");
	                WatchKey key = watcher.take();
	                System.out.println("trueeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
	                Thread.sleep(50);
	                
	                for (WatchEvent<?> event : key.pollEvents()) {
	                    WatchEvent.Kind<?> kind = event.kind();
	                    if ( StandardWatchEventKinds.ENTRY_CREATE.equals(kind)) {
	                    	configuration s=this.ReadDataDronTextFile(this.getTheFileName(chemin));
	                    	   //repo.save(s);
	                    	STEP=s.getStep();
	                    	System.out.println("fiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiin");
	                    	System.out.println(s);
	                       
	                    	System.out.println("********STEP VAR GLOBAAAL");
	                    	System.out.println(STEP);
	                    	 Thread.sleep(500);
	                    	Chataba.Mhi(this.getPath(this.getTheFileName(chemin)));
	                    }
	                }
	                key.reset();
	            }
	        } catch (IOException | InterruptedException e) {
	            e.printStackTrace();
	        }
	}
}
