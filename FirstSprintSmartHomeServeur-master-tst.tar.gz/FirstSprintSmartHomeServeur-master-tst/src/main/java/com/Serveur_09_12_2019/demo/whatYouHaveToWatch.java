package com.Serveur_09_12_2019.demo;

public enum whatYouHaveToWatch {
Temperature,Photocell,Config;
}
