package com.Serveur_09_12_2019.demo;

public class Config {
	static String Mode;
	static int Periode;
	

}
