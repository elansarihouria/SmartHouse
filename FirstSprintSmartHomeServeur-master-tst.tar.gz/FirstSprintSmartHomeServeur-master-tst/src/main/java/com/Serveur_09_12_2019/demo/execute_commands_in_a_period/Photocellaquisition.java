package com.Serveur_09_12_2019.demo.execute_commands_in_a_period;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.Serveur_09_12_2019.demo.Action;

public class Photocellaquisition implements Runnable{
	
	public Photocellaquisition() {
		
		
		super();
		// w.hdi();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		/// Action.Led(true);
		System.out.println("get Photocell");
		 Action.commad("sudo touch /home/pi/hanane/file");
	}

}
