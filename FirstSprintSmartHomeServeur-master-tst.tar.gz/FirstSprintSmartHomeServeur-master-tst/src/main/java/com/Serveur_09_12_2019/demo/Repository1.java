package com.Serveur_09_12_2019.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface Repository1 extends JpaRepository<Led,Long> {
		@Query(value="SELECT * FROM Led ORDER BY time DESC LIMIT 1;",nativeQuery = true)
		
	List<Photocell> getLastValue();
}
