package com.Serveur_09_12_2019.demo;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class GestionDeFichier {
	
	public GestionDeFichier() {
		
	}

	static public File getTheFileName(String PathOfTheFolder) {
		File folder=new File(PathOfTheFolder);
		File[] files=folder.listFiles();
		if(files[0].isFile()) {
			return files[0];
		}else {
			System.out.println("l file rah null");
			return  null;
		}
	}
	
	static public Path getPath(File f) {
		return f.toPath();
	}
	
	static public Object ReadDataDronJsonTemperature(File TheFile,whatYouHaveToWatch haveToWatch) throws JsonParseException, JsonMappingException, IOException, ParseException {
				ObjectMapper objectMapper = new ObjectMapper();
				if(haveToWatch.equals(whatYouHaveToWatch.Temperature)) {
					 Temperature temp =objectMapper.readValue(TheFile, Temperature.class);
					 if(temp.time==null) {
						 String pattern = "y-M-d H:m:s"; 
						 SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
						 temp.settime(simpleDateFormat.format(new Date()).toString());
						// temp
						// temp.settime(LocalDateTime.now().toString()); // hadchi bach yb9a 5dame hadchi wa5a l hard may3tewnach date
					 }else {
						 System.out.println("ra sefto date");
					 }
					 return temp;
				}else {
					
					JSONParser jsonParser = new JSONParser();
					 
					JSONObject configT = (JSONObject) jsonParser.parse(new FileReader("/home/hanane/Desktop/SMARTHOME/Temperature"));

					long p = (long) configT.get("p");
					long m=(long) configT.get("m");
					System.out.println("m : "+m);
					System.out.println("p : "+p);
			
					 return p;
				}
				
	}
	
	
	static public Object ReadDataDronJsonPhotocell(File TheFile,whatYouHaveToWatch haveToWatch) throws JsonParseException, JsonMappingException, IOException, ParseException {
		ObjectMapper objectMapper = new ObjectMapper();
		if(haveToWatch.equals(whatYouHaveToWatch.Photocell)) {
			Photocell ph =objectMapper.readValue(TheFile, Photocell.class);
			return ph;  
		}
		return haveToWatch;
		
}
	

static public Boolean Mhi(Path p) {
		
		try {
			Files.delete(p);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	
}
