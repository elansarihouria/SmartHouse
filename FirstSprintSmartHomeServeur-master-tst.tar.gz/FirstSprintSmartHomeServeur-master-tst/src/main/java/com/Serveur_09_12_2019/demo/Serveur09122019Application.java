package com.Serveur_09_12_2019.demo;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

@SpringBootApplication
@Configuration
@EnableScheduling
public class Serveur09122019Application {
	
	public static void main(String[] args) throws FileNotFoundException, IOException, ParseException {
		ConfigurableApplicationContext context =SpringApplication.run(Serveur09122019Application.class, args);
		 TraitementTemperature traitementTemperature=context.getBean(TraitementTemperature.class);
		 traitementTemperature.lancer();
		  System.out.println("asldasl");
		  
		  
	}
}
