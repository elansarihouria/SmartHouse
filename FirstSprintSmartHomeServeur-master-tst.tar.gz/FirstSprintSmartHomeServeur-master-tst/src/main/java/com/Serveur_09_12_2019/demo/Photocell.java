package com.Serveur_09_12_2019.demo;

import javax.persistence.Entity;
import javax.persistence.Id;


public class Photocell {
@Id
int id;
int value;
public Photocell(int id, int value) {
	super();
	this.id = id;
	this.value = value;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getValue() {
	return value;
}
public void setValue(int value) {
	this.value = value;
}

}
