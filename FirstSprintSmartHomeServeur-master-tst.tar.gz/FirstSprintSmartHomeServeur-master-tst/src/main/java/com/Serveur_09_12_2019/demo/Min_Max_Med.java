package com.Serveur_09_12_2019.demo;

public class Min_Max_Med {

	float Min;
	float Max;
	float Med;
	
	
	
	
	public Min_Max_Med(float min, float max, float med) {
		super();
		Min = min;
		Max = max;
		Med = med;
	}
	
	public float getMin() {
		return Min;
	}
	public void setMin(float min) {
		Min = min;
	}
	public float getMax() {
		return Max;
	}
	public void setMax(float max) {
		Max = max;
	}
	public float getMed() {
		return Med;
	}
	public void setMed(float med) {
		Med = med;
	}
	
	@Override
	public String toString() {
		return "Min_Max_Med [Min=" + Min + ", Max=" + Max + ", Med=" + Med +  "]";
	}
	
	
}
