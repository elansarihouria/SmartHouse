package com.Serveur_09_12_2019.demo;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface Repositry extends JpaRepository<Temperature, LocalDateTime> {
	
	@Query(value="SELECT * FROM Temperature ORDER BY time DESC LIMIT 1;",nativeQuery = true)
	
	Temperature getLastValue();
	
	@Query(value = "SELECT MIN(value) FROM Temperature WHERE time LIKE CONCAT('%', :time, '%');",nativeQuery = true)
	float getMin(@Param("time") String time);
	
	@Query(value = "SELECT MAX(value) FROM Temperature  LIKE CONCAT('%', :time, '%');",nativeQuery = true)
	float getMax(@Param("time") String time);
	
	@Query(value = "SELECT AVG(value) FROM Temperature  LIKE CONCAT('%', :time, '%');",nativeQuery = true)
	float getAvg(@Param("time") String time);
	
	@Query(value = "SELECT * FROM Temperature WHERE time LIKE CONCAT('%', :time, '%') ;",nativeQuery = true)
	List<Temperature>  getTempOfYesterday(@Param("time") String time);
	
}
