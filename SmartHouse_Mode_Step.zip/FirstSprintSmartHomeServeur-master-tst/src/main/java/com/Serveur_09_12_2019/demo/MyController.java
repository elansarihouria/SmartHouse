package com.Serveur_09_12_2019.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {

	char c='"';
	char p=':';
	@Autowired

   TraitementTemperature tr;
	@Autowired
	Repositry repo;
	
	@GetMapping("/GetTemperature")
	@ResponseBody
	public List<Temperature> getTemperature(){
		//  System.out.println("time now : "+java.time.LocalDate.now().minus(1,ChronoUnit.DAYS));
		
		 return repo.getTempOfYesterday(java.time.LocalDate.now().minus(1,ChronoUnit.DAYS).toString());
		 // return repo.findAll();
	}
	
	@GetMapping("/LedOn")
	@ResponseBody
	public boolean LedOn(){
		// hyade  hadl lcomentarire Action.commad("hna kta l commad li katch3al led");
		return true;
	}
	
	@GetMapping("/LedOff")
	@ResponseBody
	public boolean LedOff(){
		
		// hyade  hadl lcomentarire Action.commad("hna kta l commad li katfi led");;
		
		return false;
	}
	
	@GetMapping("/getTempNow")
	 @ResponseBody
	 public Temperature getTempNow() {
		 return repo.getLastValue();
	 }
	 
	
	
	 @GetMapping("/getInfoTemp")
	 @ResponseBody
	 public Min_Max_Med getInfo() {
		 String timeYesterday=java.time.LocalDate.now().minus(1,ChronoUnit.DAYS).toString();
		 Min_Max_Med m=new Min_Max_Med(repo.getMin(timeYesterday), repo.getMax(timeYesterday), repo.getAvg(timeYesterday));
		 return m;
	 }
	 
	 // hadchi darto houria 
	 
	 @GetMapping(path="/config/{mode}/{period}/")
	 @ResponseBody
	 public String getstep(@PathVariable(value = "period") int p,@PathVariable(value = "mode") String m) throws IOException {
		 Path path = Paths.get("/home/houria/Documents/GSEII2/smartHouse/tempoConfig/t");
		 GestionDeFichier.Mhi(path);
		 File myObj=new File("/home/houria/Documents/GSEII2/smartHouse/tempoConfig/t");
		String strValue ="{ \"p\" : " +p+ "\n\"m\" : " +"\""+m+"\""+"}"; 
		System.out.println(strValue);
		// Path path = Paths.get(fileName);
		 byte[] bytes = strValue.getBytes() ;
		 Files.write(path, bytes);
	     return strValue;
	 }
	 @GetMapping("/start")
	 @ResponseBody
	 public String init() {
	
			int p=tr.getPeriode();
			String m=tr.getMode();
		String strValue ="{ \"p\" : " +p+ "\n\"m\" : " +"\""+m+"\""+"}"; 
		 return strValue;
	 }
	 

	 
	
}
