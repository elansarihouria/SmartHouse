package com.Serveur_09_12_2019.demo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.Serveur_09_12_2019.demo.execute_commands_in_a_period.getTemperature;

@Component
public class TraitementTemperature {
	
	@Autowired
	 Repositry repo;
	static configuration confi;
	static private  int Periode;
	static private String Mode;
	
	static ScheduledExecutorService scheduledExecutorService;
	
	public TraitementTemperature() throws FileNotFoundException, IOException, ParseException {
		super();
	}
	
	public static String getMConfi() {
		return confi.getMode();
	}
	
	public static int getPConfi() {
		return confi.getPeriode();
	}

	public static void setConfi(configuration confi) {
		TraitementTemperature.confi = confi;
	}

	public int getPeriode() {
		return Periode;
	}
	public String getMode() {
		return Mode;
	}
	public void setMode(String Mode) {
		this.Mode =Mode;
	}
	
	public void setPeriode(int periode) {
		Periode = periode;
	}
	
	public void lancer() throws FileNotFoundException, IOException, ParseException {
		this.LookForPeriod();
		System.out.println(Mode);
		scheduledExecutorService=Executors.newScheduledThreadPool(1);
		scheduledExecutorService.scheduleAtFixedRate(new getTemperature(),0,this.Periode, TimeUnit.SECONDS);
		
		Thread test=new Thread(new Runnable() {
			public void run() {
				try {
					// hdi(whatYouHaveToWatch.Periode);
					hdi(whatYouHaveToWatch.Temperature);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		Thread test2=new Thread(new Runnable() {
			public void run() {
				try {
					// hdi(whatYouHaveToWatch.Periode);
					hdi(whatYouHaveToWatch.Config);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		 test.start();
		 test2.start();
	}
	
	public void LookForPeriod() throws FileNotFoundException, IOException, ParseException {
		JSONParser jsonParser = new JSONParser();
		 
		JSONObject config = (JSONObject) jsonParser.parse(new FileReader("/home/houria/Documents/GSEII2/smartHouse/tempoConfig/t"));
		System.out.println("dddddddddddddddddddddddddddddddddddddddddddd");
           
		long p = (long) config.get("p");
		System.out.println("p : "+p);
		Periode = (int)p;
		String m=(String) config.get("m");
		System.out.println("m : "+m);
		Mode =(String)m;
		
	}
	
	public void hdi(whatYouHaveToWatch haveToWatch) throws ParseException {
		   try( WatchService watcher = FileSystems.getDefault().newWatchService()) {
	            // Creates a instance of WatchService.
			   	 String chemin;
			   	if(haveToWatch.equals(whatYouHaveToWatch.Temperature)) {
			   		
			   		chemin="/home/houria/Documents/GSEII2/smartHouse/tempFolder";
			   	}else { 
			   		chemin="/home/houria/Documents/GSEII2/smartHouse/tempoConfig" ;
			   			
			   	}
	            // Registers the logDir below with a watch service.
	            Path logDir = Paths.get(chemin);
	            logDir.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
	            
	            // Monitor the logDir at listen for change notification.
	            while (true) {
	            	//System.out.println("lllfl");
	                WatchKey key = watcher.take();
	                
	                Thread.sleep(50);
	                
	                for (WatchEvent<?> event : key.pollEvents()) {
	                    WatchEvent.Kind<?> kind = event.kind();
	                    if ( StandardWatchEventKinds.ENTRY_CREATE.equals(kind)) {
	                    	if(haveToWatch.equals(whatYouHaveToWatch.Temperature)) {
	                    		Temperature t=(Temperature)GestionDeFichier.ReadDataDronJsonFile(GestionDeFichier.getTheFileName(chemin),whatYouHaveToWatch.Temperature);
		                    	System.out.println(t);
		                    	 repo.save(t);
		                    	 Thread.sleep(500);
		                    	 GestionDeFichier.Mhi(GestionDeFichier.getPath(GestionDeFichier.getTheFileName(chemin)));
	                    	}else {
	                    		this.LookForPeriod();
	                    		System.out.println("Bdalti fl configuration");
	                    		confi.setMode(Mode);
	                    		confi.setPeriode(Periode);
	                    		  scheduledExecutorService.shutdown();
	                    		  scheduledExecutorService=Executors.newScheduledThreadPool(1);
	                    		scheduledExecutorService.scheduleAtFixedRate(new getTemperature(),0,this.Periode, TimeUnit.SECONDS);
	                    	
	                    		
	                    	}
	                    }
	                }
	                key.reset();
	            }
	        } catch (IOException | InterruptedException e) {
	            e.printStackTrace();
	        }
	}

}
