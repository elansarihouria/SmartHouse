package com.Serveur_09_12_2019.demo;

import javax.persistence.Entity;
import javax.persistence.Id;


public class configuration {
   int Periode ;
	String Mode;

	public configuration() {
	super();
	}

	public int getPeriode() {
		return Periode;
	}

	public void setPeriode(int periode) {
		Periode = periode;
	}

	public String getMode() {
		return Mode;
	}

	public void setMode(String mode) {
		Mode = mode;
	}

	@Override
	public String toString() {
		return "configuration [Periode=" + Periode + ", Mode=" + Mode + "]";
	}


}
