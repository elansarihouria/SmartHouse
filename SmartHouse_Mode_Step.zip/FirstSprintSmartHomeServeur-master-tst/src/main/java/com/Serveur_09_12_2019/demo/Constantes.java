package com.Serveur_09_12_2019.demo;

public class Constantes {
	static int Periode=2000;
	static String Mode="automatic";

}
